import { Link, useNavigate } from "react-router-dom";
import { Logo } from "./Logo";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/context/AuthContext";
import { 
  LogOut, 
  User as UserIcon, 
  LayoutDashboard, 
  Search, 
  PlusCircle, 
  Bell, 
  Stethoscope 
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

interface LayoutProps {
  children: React.ReactNode;
}

export function Layout({ children }: LayoutProps) {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate("/");
  };

  return (
    <div className="min-h-screen bg-background text-foreground selection:bg-primary/20">
      <header className="fixed top-0 left-0 right-0 z-50 border-b bg-background/80 backdrop-blur-md">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <Link to="/" className="group flex items-center gap-2">
            <Logo className="h-10 transition-all duration-300 group-hover:drop-shadow-[0_0_8px_rgba(0,114,206,0.5)]" showGlow />
            <div className="flex flex-col -gap-1">
               <span className="text-xl font-black tracking-tighter text-primary">TAKYMED</span>
               <span className="text-[8px] font-bold tracking-[0.2em] text-muted-foreground uppercase -mt-1 ml-1">Take Your Medicine</span>
            </div>
          </Link>
          
          <nav className="hidden md:flex items-center gap-8 text-sm font-medium">
            {user ? (
              <>
                <Link to="/dashboard" className="flex items-center gap-2 hover:text-primary transition-colors">
                  <LayoutDashboard className="w-4 h-4" />
                  Tableau de bord
                </Link>
                <Link to="/prescription" className="flex items-center gap-2 hover:text-primary transition-colors">
                  <PlusCircle className="w-4 h-4" />
                  Ordonnance
                </Link>
                <Link to="/search" className="flex items-center gap-2 hover:text-primary transition-colors">
                  <Search className="w-4 h-4" />
                  Médicaments & Stocks
                </Link>
                {user.type === "pharmacist" && (
                  <Link to="/pharmacy-mgmt" className="flex items-center gap-2 hover:text-primary transition-colors">
                    <Stethoscope className="w-4 h-4" />
                    Mes Pharmacies
                  </Link>
                )}
                <Link to="/ads" className="flex items-center gap-2 hover:text-primary transition-colors">
                  <Bell className="w-4 h-4" />
                  Nouveautés
                </Link>
              </>
            ) : null}
          </nav>

          <div className="flex items-center gap-4">
            {!user ? (
              <>
                <Link to="/login">
                  <Button variant="ghost" size="sm">
                    Connexion
                  </Button>
                </Link>
                <Link to="/register">
                  <Button size="sm">S'inscrire</Button>
                </Link>
              </>
            ) : (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="sm" className="gap-2 bg-slate-50 border rounded-full px-4 h-10">
                    <UserIcon className="h-4 w-4" />
                    <span className="hidden sm:inline truncate max-w-[100px]">{user.email}</span>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56 rounded-2xl">
                  <DropdownMenuLabel>Mon Compte</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem className="gap-2 cursor-pointer" onClick={() => navigate("/dashboard")}>
                    <UserIcon className="h-4 w-4" /> Profil ({user.type})
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem 
                    className="gap-2 text-destructive focus:text-destructive cursor-pointer" 
                    onClick={handleLogout}
                  >
                    <LogOut className="h-4 w-4" /> Déconnexion
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            )}
          </div>
        </div>
      </header>
      <main className="pt-16 min-h-[calc(100vh-64px-300px)]">{children}</main>
      <footer className="bg-muted py-12 border-t">
        <div className="container mx-auto px-4 grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="col-span-1 md:col-span-2 space-y-6">
            <div className="flex items-center gap-3">
               <Logo className="h-8" />
               <span className="text-2xl font-black tracking-tighter text-slate-800">TAKYMED</span>
            </div>
            <p className="text-muted-foreground text-sm max-w-xs leading-relaxed">
              TAKYMED : Votre allié pour une gestion optimale de vos ordonnances et rappels de médicaments.
              Assurez-vous de prendre vos médicaments au bon moment.
            </p>
          </div>
          <div className="space-y-4">
            <h4 className="font-semibold">Services</h4>
            <ul className="text-sm space-y-2 text-muted-foreground">
              <li>
                <Link to="/search" className="hover:text-primary">Recherche</Link>
              </li>
              <li>
                <Link to="/prescription" className="hover:text-primary">Ordonnances</Link>
              </li>
              <li>
                <Link to="/ads" className="hover:text-primary">Nouveautés</Link>
              </li>
            </ul>
          </div>
          <div className="space-y-4">
            <h4 className="font-semibold">Légal</h4>
            <ul className="text-sm space-y-2 text-muted-foreground">
              <li>Confidentialité</li>
              <li>Conditions d'utilisation</li>
            </ul>
          </div>
        </div>
        <div className="container mx-auto px-4 pt-8 mt-8 border-t text-center text-xs text-muted-foreground">
          © {new Date().getFullYear()} TAKYMED. Tous droits réservés.
        </div>
      </footer>
    </div>
  );
}

import { cn } from "@/lib/utils";

interface LogoProps {
  className?: string;
}

export function Logo({ className, showGlow = false }: LogoProps & { showGlow?: boolean }) {
  return (
    <div className={cn("relative group flex items-center gap-2", className)}>
      {showGlow && (
        <div className="absolute -inset-4 bg-primary/20 rounded-full blur-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
      )}
      <div className="relative transform transition-transform duration-500 group-hover:scale-110">
        <img
          src="https://cdn.builder.io/api/v1/image/assets%2F41ba66cdc7114e4ab014f35ba81e151e%2F5a1738089420488d8180d4d1ece4bdbd?format=webp&width=800&height=1200"
          alt="TAKYMED Logo"
          className="h-full w-auto drop-shadow-md"
        />
      </div>
    </div>
  );
}
